PORTUGAL VS ANJRTINA — Android Studio project

WANTI:
- Kun Android Studio keessatti APK ijaaruu dandeessuuf source project dha; APK qophaa'e miti.
- Chat live Firebase config sirrii fi Realtime Database + Anonymous Authentication barbaada.
- Internet barbaachisa.
- Firebase config app keessa galchuun qofa database rules nageenya qabu jechuu miti. App ummataaf banuun dura rules nageenya qabu qindeessi.

TARKAANFII:
1. PC irratti Android Studio (https://developer.android.com/studio) install godhi.
2. ZIP kana extract godhi.
3. Android Studio > Open > folder PortugalVsAnjrtina filadhu.
4. Gradle sync xumuru eegi.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) filadhu.
6. Build xumurame booda "locate" tuqi; app-debug.apk argatta.
7. APK bilbila Samsung keetti ergi, faayila tuqi, yoo gaafate "Install unknown apps" hayyami, Install tuqi.

FIREBASE:
1. https://console.firebase.google.com bana, project haaraa uumi.
2. Add app > Web (</>) filadhu; Firebase config kee copy godhi.
3. Build > Realtime Database > Create database.
4. Build > Authentication > Get started > Sign-in method > Anonymous enable godhi.
5. App bilbila irratti banuun Firebase qindeessi kutaa "Firebase qindeessi" keessatti config JSON guutuu galchi.
6. Realtime Database rules default deny yoo ta'e chat hin hojjetu. Production irratti authentication-based rules fayyadami; public read/write hin banin.

BILBILA QOFA QABDAA?
APK ijaaruun yeroo baay'ee PC/Android Studio barbaada. HTML qofa APK hin ta'u. Faayila project kana nama Android Studio qabuuf erguun ni danda'ama.
